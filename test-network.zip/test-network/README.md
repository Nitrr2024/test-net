# Fabric Advance Topics

This repository contains the advance fabric topics with the link to the details explanation. If you find this repository **, Please Star and Fork this repository** it really gives me motivation to make such content and you can also follow me on [medium](https://adityaajoshi.medium.com/) for such content.

# Content

- [Modifying the Batch Size in Hyperledger Fabric v2.2](https://medium.com/coinmonks/modifying-the-batch-size-in-hyperledger-fabric-v2-2-3ec2dd779e2b)
- [Integrating Hyperledger Explorer with Hyperledger Fabric Network v2.2](https://medium.com/coinmonks/integrating-hyperledger-explorer-with-hyperledger-fabric-network-v2-2-9a70e4c5311)
- [Adding a new Orderer in Running Hyperledger Fabric v2.2 Network](https://medium.com/coinmonks/adding-a-new-orderer-in-running-hyperledger-fabric-v2-2-network-4c90c8315ae1)
- [Getting Started - Hyperledger Fabric 2.2 Tutorial](https://adityaajoshi.medium.com/hyperledger-fabric-2-2-tutorial-eb21618d5fa)

You can checkout my [course on Hyperledger Fabric Deployment on MultiHost on Udemy](https://bit.ly/hlf-multihost-deployment)

```
./network.sh up createChannel  -ca -s couchdb -c mycc
```

```
./network.sh deployCC -ccn mycc1 -c mycc -ccp ../asset-transfer-basic/chaincode-go/ -ccl go
```
